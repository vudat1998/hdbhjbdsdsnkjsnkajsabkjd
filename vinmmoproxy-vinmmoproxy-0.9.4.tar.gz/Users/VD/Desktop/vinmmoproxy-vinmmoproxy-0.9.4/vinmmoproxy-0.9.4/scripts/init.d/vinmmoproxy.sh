#!/bin/sh
### BEGIN INIT INFO
# Provides:          vinmmoproxy
# Required-Start:    
# Required-Stop:     
# Should-Start:      
# Should-Stop:       
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start/stop vinmmoproxy
# Description:       Start/stop vinmmoproxy, tiny proxy server
### END INIT INFO
# chkconfig: 2345 20 80
# description: vinmmoproxy tiny proxy server

case "$1" in
   start)    
       echo Starting vinmmoproxy
   
       /bin/mkdir -p /var/run/vinmmoproxy
       /bin/vinmmoproxy /etc/vinmmoproxy/vinmmoproxy.cfg &
   
       RETVAL=$?
       echo
       [ $RETVAL ]    
       ;;

   stop)
       echo Stopping vinmmoproxy
       if [ -f /var/run/vinmmoproxy/vinmmoproxy.pid ]; then
	       /bin/kill `cat /var/run/vinmmoproxy/vinmmoproxy.pid`
       else
               /usr/bin/killall vinmmoproxy
       fi
   
       RETVAL=$?
       echo
       [ $RETVAL ]
       ;;

   restart|reload)
       echo Reloading vinmmoproxy
       if [ -f /var/run/vinmmoproxy/vinmmoproxy.pid ]; then
	       /bin/kill -s USR1 `cat /var/run/vinmmoproxy/vinmmoproxy.pid`
       else
               /usr/bin/killall -s USR1 vinmmoproxy
       fi
       ;;


   *)
       echo Usage: $0 "{start|stop|restart}"
       exit 1
esac
exit 0 

