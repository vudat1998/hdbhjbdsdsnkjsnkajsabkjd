#!/bin/sh
cd ..
cp Makefile.unix Makefile
make
if [ ! -d /usr/local/etc/vinmmoproxy/bin ]; then mkdir -p /usr/local/etc/vinmmoproxy/bin/; fi
install bin/vinmmoproxy /usr/local/bin/vinmmoproxy
install bin/mycrypt /usr/local/bin/mycrypt
install scripts/rc.d/proxy.sh /usr/local/etc/rc.d/proxy.sh
install scripts/addvinmmoproxyuser.sh /usr/local/etc/vinmmoproxy/bin/
if [ -s /usr/local/etc/vinmmoproxy/vinmmoproxy.cfg ]; then
 echo /usr/local/etc/vinmmoproxy/vinmmoproxy.cfg already exists
else
 install scripts/vinmmoproxy.cfg /usr/local/etc/vinmmoproxy/
 if [ ! -d /var/log/vinmmoproxy/ ]; then
  mkdir /var/log/vinmmoproxy/
 fi
 touch /usr/local/etc/vinmmoproxy/passwd
 touch /usr/local/etc/vinmmoproxy/counters
 touch /usr/local/etc/vinmmoproxy/bandlimiters
 echo Run /usr/local/etc/vinmmoproxy/bin/addvinmmoproxyuser.sh to add \'admin\' user
fi

