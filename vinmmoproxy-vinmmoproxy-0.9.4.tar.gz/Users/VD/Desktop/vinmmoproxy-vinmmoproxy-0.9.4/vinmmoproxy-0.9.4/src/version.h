#ifndef VERSION
#define VERSION "vinmmoproxy-0.9.3"
#endif
#ifndef BUILDDATE
#define BUILDDATE ""
#endif
#define MAJORvinmmoproxy 0
#define SUBMAJORvinmmoproxy 9
#define MINORvinmmoproxy 3
#define SUBMINORvinmmoproxy 0
#define RELEASEvinmmoproxy "vinmmoproxy-0.9.3(" BUILDDATE ")\0"
#define YEARvinmmoproxy "2021"
